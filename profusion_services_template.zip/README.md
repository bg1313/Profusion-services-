# Profusion Services Website Template

## Description
A simple static site for Profusion Services, including educational Pump Packets.

## How to Deploy on Vercel
1. Fork or clone this repository.
2. Sign in to Vercel and select 'New Project'.
3. Import this repository.
4. Vercel auto-detects a static site (HTML/CSS).
5. Click 'Deploy'. Your site will be live!

## Customization
- Replace index.html and style.css with your final versions.
- Add more files to /assets as needed.

## Contact
Email: info@profusionservices.com
